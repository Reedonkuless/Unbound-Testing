# Pokémon Unbound Save Studio v0.4.0 — Unified ROM integration

**Status: PASS — local integration + round-trip QA closed**

Frozen ROM output:
- SHA-1 `49a70fbfeb01fa6a3c6a163bea63e6c3f9ff9cda`
- SHA-256 `bdd8ac767412b3c667cac1304c88d786c760100d53dd9873267d7459647f9734`

Supported exact base:
- SHA-1 `b4776b82a4c7915d0fadeaa27e013523f99dfd94`
- SHA-256 `7aa25bbf568f7cfcf6ee1cf2e9e6ff637350b3d0705c2375cabb6baa7d9739f7`

Editor integration:
- 1298 Grimble / 1299 Gravibite / 1300 Dreadchomp / 1301 Frostyrant / 1302 Mournevoir
- item 729 Dark Requiem
- move 923 Glacial Rend, 10 PP
- move 924 TyrantPrison, 5 PP
- Permafrost remains numeric ability 77
- Heart of Darkness is virtual/species-scoped on Mournevoir; Save Studio preserves carrier ability 0 and slot 0 rather than assigning a fake ability ID
- searchable species/item/move fields retained

Round-trip QA PASS:
- Party and PC Mournevoir write/readback
- Dark Requiem persistence
- custom move IDs and PP persistence
- Heart virtual display / carrier-0 preservation
- Frostyrant/Permafrost regression
- `.sav`/`.srm` conversion round trip
- source save unchanged
- browser UPF patcher rebuilds exact accepted final ROM byte-for-byte
- unsupported ROM refused

Production deployment remains unchanged. Next gate: hosted UI smoke, then explicit production promotion.
