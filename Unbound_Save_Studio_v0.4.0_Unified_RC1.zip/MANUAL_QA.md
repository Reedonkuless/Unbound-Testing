# Pokémon Unbound unified release candidate — verification guide

This package contains the Save Studio and the deterministic unified ROM patcher. It contains **no ROM and no save**. Keep your original ROM and primary save backed up.

## Frozen ROM target

The browser patcher accepts only the exact Pokémon Unbound v2.1.1.1 base:

- SHA-1 `b4776b82a4c7915d0fadeaa27e013523f99dfd94`
- SHA-256 `7aa25bbf568f7cfcf6ee1cf2e9e6ff637350b3d0705c2375cabb6baa7d9739f7`

It produces only the frozen unified ROM:

- SHA-1 `49a70fbfeb01fa6a3c6a163bea63e6c3f9ff9cda`
- SHA-256 `bdd8ac767412b3c667cac1304c88d786c760100d53dd9873267d7459647f9734`

Open `rom-patcher/index.html` through a local/static web server or the deployed site and select the original 32 MiB ROM. The ROM is processed locally.

## Unified custom content

- 1298 Grimble
- 1299 Gravibite
- 1300 Dreadchomp
- 1301 Frostyrant
- 1302 Mournevoir
- ability 77 Permafrost
- virtual species ability Heart of Darkness on Mournevoir, carrier ability 0
- move 923 Glacial Rend — 10 PP
- move 924 TyrantPrison — 5 PP
- item 729 Dark Requiem

## Save Studio checks

The v0.4.0 editor supports searchable species, item and move fields, native per-species ability slot selection, Party editing, PC editing, creation, and `.sav`/`.srm` export. Mournevoir intentionally shows **Heart of Darkness · Virtual** and keeps ability slot 0/carrier ability 0; no fake numeric Heart ability is written.

The automated v0.4.0 round-trip suite passed:

- Mournevoir Party write/readback with Dark Requiem and moves 94/188/923/924
- exact PP readback 10/10/10/5
- Mournevoir PC insertion/readback
- Heart of Darkness display with carrier ability 0 and slot 0
- Frostyrant regression: Permafrost remains ability 77
- `.sav` → `.srm` → `.sav` parser round trip
- source save unchanged
- browser UPF patcher output byte-identical to the frozen final ROM
- unsupported ROM input rejected

## Gameplay release evidence already closed

The frozen final ROM already passed the prior Mournevoir/Dark Requiem and Garchomp/Frostyrant release gates, including evolution, Heart behavior, Dark Requiem behavior, sprites/icon, Pokédex, cry, item animation, TM/tutor behavior, signature moves, ordinary save/reload, longer-play checks, and the final cross-project collision audit.

## Remaining release action

The remaining step after this package is a hosted UI smoke test and production deployment of v0.4.0. Production should not be changed until that hosted smoke is clean.
