Pokémon Unbound Save Studio v0.4.0 + final unified ROM patcher.

Open index.html through a static web server for save editing, or rom-patcher/index.html for the exact deterministic ROM patcher.

The package contains no ROM and no save. The patcher accepts only the exact original Pokémon Unbound v2.1.1.1 ROM and verifies the frozen final output hash before download.

See CHECKPOINT.md, MANUAL_QA.md, and Unbound_Save_Studio_v0.4.0_RoundTrip_QA.json.
