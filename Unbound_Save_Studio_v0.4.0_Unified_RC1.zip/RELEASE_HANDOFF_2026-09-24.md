# Pokémon Unbound — Save Studio v0.4.0 release handoff

## Current authority
The ROM-side configuration is frozen at SHA-256 `bdd8ac767412b3c667cac1304c88d786c760100d53dd9873267d7459647f9734`. The deterministic browser patcher in this package applies the same UPF1 record stream used by the verified offline final patcher.

## Editor status
Save Studio v0.4.0 understands all currently finalized custom IDs: species 1298–1302, item 729, moves 923/924, Permafrost 77, and Mournevoir's virtual Heart of Darkness architecture. Heart remains carrier ability 0; the editor does not allocate or write a numeric Heart ability ID.

## QA status
Local module syntax, save round-trip, PC round-trip, Party round-trip, save-format conversion, Frostyrant regression, exact ROM patch output, and unsupported-input guard are PASS. See `Unbound_Save_Studio_v0.4.0_RoundTrip_QA.json`.

## Release boundary
This package has not been promoted to the production Vercel deployment. The next action is hosted preview/UI smoke at `/` and `/rom-patcher/`; if clean, promote v0.4.0 to production and record deployment ID + browser evidence.
