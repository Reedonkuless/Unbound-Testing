# Pokémon Unbound — Final Deterministic Unified ROM Patcher Verification

**Verification date:** 2026-09-24  
**Result:** PASS

## Final patcher bundle

- File: `Unbound_Final_Unified_ROM_Patcher_2026-09-23.zip`
- SHA-1: `ae9071a4016dc72a4f5302d093c3b7e104b8a13f`
- SHA-256: `86ff45717d7132f1349a370c4ddffc9867d627eabe4bd302b8a1419a096a36b6`
- Size: 140,450 bytes
- ROM bundled: No

## Exact supported base

- Pokémon Unbound v2.1.1.1
- Size: 33,554,432 bytes
- SHA-1: `b4776b82a4c7915d0fadeaa27e013523f99dfd94`
- SHA-256: `7aa25bbf568f7cfcf6ee1cf2e9e6ff637350b3d0705c2375cabb6baa7d9739f7`

The base ROM was freshly materialized from the connected Pokémon Unbound Drive folder and its hashes matched the patcher's required input guard exactly.

## Patch payload

- Format: UPF1 deterministic record stream, zlib compressed
- Records: 767
- Payload: `Unbound_Final_Unified_2026-09-23.upf.zlib`
- Payload size: 139,784 bytes
- Payload SHA-256: `959160f2f9f92cd81b2af98f59e5d43133fd23f4889b88f356421d064dcd6ef0`

## Exact accepted output

- Size: 33,554,432 bytes
- SHA-1: `49a70fbfeb01fa6a3c6a163bea63e6c3f9ff9cda`
- SHA-256: `bdd8ac767412b3c667cac1304c88d786c760100d53dd9873267d7459647f9734`

## Fresh reproducibility rerun

Three fresh independent applications were performed from the exact supported base using the packaged applicator and payload.

- Run 1: SHA-1 `49a70fbfeb01fa6a3c6a163bea63e6c3f9ff9cda`; SHA-256 `bdd8ac767412b3c667cac1304c88d786c760100d53dd9873267d7459647f9734`; byte-identical to accepted final: YES
- Run 2: SHA-1 `49a70fbfeb01fa6a3c6a163bea63e6c3f9ff9cda`; SHA-256 `bdd8ac767412b3c667cac1304c88d786c760100d53dd9873267d7459647f9734`; byte-identical to accepted final: YES
- Run 3: SHA-1 `49a70fbfeb01fa6a3c6a163bea63e6c3f9ff9cda`; SHA-256 `bdd8ac767412b3c667cac1304c88d786c760100d53dd9873267d7459647f9734`; byte-identical to accepted final: YES
- Run 1 = Run 2: YES
- Run 2 = Run 3: YES

## Input guard rerun

The accepted final ROM itself was deliberately supplied as an unsupported input. The patcher returned code 1 with:

`REFUSED: input ROM hash is not the exact supported Unbound v2.1.1.1 base.`

No output file was written.

## Release state

The ROM-side configuration is frozen and deterministic. This is the exact final unified configuration that passed the Mournevoir/Dark Requiem and Garchomp/Frostyrant release gates. Save Studio/editor integration remains a separate next step.
