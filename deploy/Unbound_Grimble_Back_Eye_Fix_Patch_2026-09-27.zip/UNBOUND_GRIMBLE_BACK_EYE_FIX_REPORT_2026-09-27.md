# Pokémon Unbound — Grimble Back-Sprite Eye Fix

**Date:** 2026-09-27  
**Status:** CORRECTED TARGET BUILT / CLEAN-BASE UPF VERIFIED / BOOT ORACLE PASS

## Finding

The current recovered ROM still used the older pre-eye-fix Grimble back-sprite bytes.

The finalized Drive authority is:

- `grimble_back_indexed_64x64.png`
- Drive file ID: `1GGwomcgS-dtaDpcFx2QFFXZtcn7GKm5h`
- PNG SHA-256: `153fb768703ce70db93f72e126797c15c133df0ddf5d73620297562085a845a4`
- 64x64 indexed PNG
- 13 active palette entries including transparency
- deployment note: use for Grimble back sprite only; do not overwrite base Gible

The finalized PNG differs from the older source only in the intended eye/face region.

## Live ROM surface

Species:
- Grimble = 1298 / 0x512

Post-Mournevoir live back-pic table:
- table file offset: `0x01633C64`
- Grimble row file offset: `0x016364F4`
- back-sprite pointer: `0x09FE7568`
- compressed asset file offset: `0x01FE7568`

The final eye-fixed asset was converted through the same historical pipeline:
1. indexed 64x64 PNG -> tiled GBA 4bpp
2. source palette -> GBA BGR555
3. remap into the existing Grimble front/shared battle palette
4. deterministic literal-only GBA LZ77

Final mapped raw 4bpp SHA-256:
`7b9f78ffcbe88f1162cb15cf2ebb4dbd688fa632f7ce13478c82f7c3c8976f4d`

Only 26 bytes of the existing compressed Grimble back sprite changed relative to the v0.5.3 Dreadchomp live-table build. No pointer, palette, species, save, item, move, ability, or evolution bytes changed.

## Corrected target

`Pokemon Unbound - Recovered CP33 Grimble Eye Fix.gba`

- SHA-1: `705bf4e8fc5ac80a9790d99f76acecd90743ccbd`
- SHA-256: `2d059a184bb1a04beb8c8ce9627697f4ff4904e07dc2f147ebeb7b8bf7fdfb8b`
- size: 33,554,432 bytes

## Clean-base recovery patch

`Unbound_Latest_Recovered_CP33_GrimbleEyeFix_2026-09-27.upf`

- SHA-256: `182f8164a374fcd4780bb7a52c83542cd6972b1ea0989269525f0ee0c688507f`
- record count: 781
- physical changed bytes: 510,925
- payload size: 517,185 bytes
- independent clean-base applications: 3/3 byte-identical

Compressed:
- SHA-256: `85c9b3ae9b98d93675b929d1bec797b01e5c910c128bb6eb744fdb07e6867ebb`

## Boot smoke

600-frame mGBA framebuffer SHA-256:
`9f939df8dfb9b539c74f628bec407f775be950e4d950a820da4ee5e03622e15c`

This matches the established project boot oracle exactly.

## Important manual-test note

A screenshot that displays the battle name **Gible** is testing native Gible, not custom Grimble. The finalized Drive deployment contract explicitly says not to overwrite base Gible's back sprite. To verify this fix in-game, the battler must actually be species **1298 Grimble** and display the name `Grimble`.
