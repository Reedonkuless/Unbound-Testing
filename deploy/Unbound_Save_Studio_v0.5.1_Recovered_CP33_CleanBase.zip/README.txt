Pokémon Unbound Save Studio v0.5.1 — Recovered CP33 clean-base candidate

The Save Studio metadata covers the five custom species, abilities, moves, and items.
The ROM patcher at /rom-patcher/ now accepts the untouched Pokémon Unbound v2.1.1.1 ROM directly and produces the deterministic recovered CP33 candidate.

The package contains no ROM or save. The historical CP27 binary was not retained; the new target is a documented reconstruction with a new hash. See RELEASE_HANDOFF_2026-09-26_RECOVERED_CP33.md and Unbound_Save_Studio_v0.5.1_Recovered_CP33_QA.json.
