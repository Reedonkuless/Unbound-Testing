# Pokémon Unbound — Recovered CP33 Clean-Base Candidate

**Date:** 2026-09-26  
**Status:** DETERMINISTIC RECOVERY CANDIDATE / STATIC + COLD-BOOT PASS / PRODUCTION NOT PROMOTED

## Why this build exists
The historical Checkpoint-27 ROM (`27995aec07b7111645161b4d29698d7d21e55ac9`) was validated but its exact binary bytes were not retained. This recovery reconstructs the latest accepted design from the retained RC5 clean-base path and authoritative checkpoints. It intentionally receives a **new target hash** rather than falsely claiming byte identity with the lost CP27 file.

## Exact clean input
- SHA-1 `b4776b82a4c7915d0fadeaa27e013523f99dfd94`
- SHA-256 `7aa25bbf568f7cfcf6ee1cf2e9e6ff637350b3d0705c2375cabb6baa7d9739f7`
- 33,554,432 bytes

## Recovered target
- SHA-1 `1037b82bd50a4cad4d3fa63316da79f403e0e7d1`
- SHA-256 `9c52a435a7159a721bf6fd532fa03e4bb435ddf4956b6a5c6c14a83e92ac288f`
- 33,554,432 bytes

## Included project state
- species 1298 Grimble, 1299 Gravibite, 1300 Dreadchomp, 1301 Frostyrant, 1302 Mournevoir
- Permafrost and reconstructed Eclipse Heart
- moves 923 Glacial Rend, 924 TyrantPrison, 925 Dark Whisper, 926 Fey Bane
- Soul Requiem item729 and Tyrant's Crown item730 / Frozen Sovereignty
- Mournevoir final stats 68/85/65/165/135/100
- female Gardevoir Lv60+ + Soul Requiem + Dusk Stone evolution route
- final mixed-case species names and approved 32x64 party-icon sheets
- final Soul Dew and Relic Crown item artwork decisions

## Verification in this recovery pass
- RC5 rebuild from clean base reproduced `ac072162770dc1e4643823bff5519b25cc43bef7`.
- CP13 and CP14 historical hashes reproduced exactly.
- final recovery builder reproduced the new target byte-for-byte in 2/2 builds.
- clean-base UPF application reproduced the target byte-for-byte in 3/3 independent applications.
- 600-frame mGBA cold boot matches the established oracle SHA-256 `9f939df8dfb9b539c74f628bec407f775be950e4d950a820da4ee5e03622e15c`.

## Important release boundary
The new hash has static and boot validation, but it has not yet repeated every historical CP27 live battle/UI matrix on this exact reconstructed binary. Do not describe it as the old CP27 file. Production deployment remains unchanged until focused same-hash runtime smoke is closed.
