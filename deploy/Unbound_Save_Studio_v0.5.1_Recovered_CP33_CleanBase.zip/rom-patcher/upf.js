// Deterministic clean-base patcher for the recovered CP33 latest build. No ROM bytes are bundled.
export const ROM_SIZE = 0x2000000;
export const SOURCE_SHA1 = 'b4776b82a4c7915d0fadeaa27e013523f99dfd94';
export const SOURCE_SHA256 = '7aa25bbf568f7cfcf6ee1cf2e9e6ff637350b3d0705c2375cabb6baa7d9739f7';
export const TARGET_SHA1 = '1037b82bd50a4cad4d3fa63316da79f403e0e7d1';
export const TARGET_SHA256 = '9c52a435a7159a721bf6fd532fa03e4bb435ddf4956b6a5c6c14a83e92ac288f';
export const RAW_PAYLOAD_SHA256 = '82a7887b91db41ff7402cd0c92e1c23ca9e1c0548940ea250fa92a12201ee33e';

async function digest(bytes, algorithm) {
  return [...new Uint8Array(await crypto.subtle.digest(algorithm, bytes))].map(v=>v.toString(16).padStart(2,'0')).join('');
}
export const sha1 = bytes => digest(bytes, 'SHA-1');
export const sha256 = bytes => digest(bytes, 'SHA-256');

export async function applyUnifiedPatch(source, payload) {
  if (source.length !== ROM_SIZE) throw new Error(`Expected ${ROM_SIZE.toLocaleString()} bytes; got ${source.length.toLocaleString()}.`);
  const [s1,s256] = await Promise.all([sha1(source),sha256(source)]);
  if (s1 !== SOURCE_SHA1 || s256 !== SOURCE_SHA256) throw new Error('This patcher requires the exact original Pokémon Unbound v2.1.1.1 ROM.');
  if (await sha256(payload) !== RAW_PAYLOAD_SHA256) throw new Error('Recovered CP33 patch payload integrity check failed.');
  if (payload.length < 12 || String.fromCharCode(...payload.subarray(0,4)) !== 'UPF1') throw new Error('Unrecognized patch payload.');
  const view = new DataView(payload.buffer,payload.byteOffset,payload.byteLength);
  const romSize=view.getUint32(4,true), count=view.getUint32(8,true);
  if (romSize !== ROM_SIZE) throw new Error('Patch payload ROM-size mismatch.');
  const output=source.slice(); let at=12, lastEnd=0;
  for(let i=0;i<count;i++){
    if(at+8>payload.length)throw new Error('Truncated patch record header.');
    const offset=view.getUint32(at,true), length=view.getUint32(at+4,true); at+=8;
    if(offset<lastEnd || offset+length>ROM_SIZE || at+length>payload.length)throw new Error('Malformed or overlapping patch record.');
    output.set(payload.subarray(at,at+length),offset); at+=length; lastEnd=offset+length;
  }
  if(at!==payload.length)throw new Error('Unexpected trailing bytes in patch payload.');
  const [o1,o256]=await Promise.all([sha1(output),sha256(output)]);
  if(o1!==TARGET_SHA1 || o256!==TARGET_SHA256)throw new Error('Patched ROM verification failed.');
  return output;
}
